"""
Utility functions for the AI Music Generation app.
"""

import os
import tempfile
import pickle
import numpy as np


NOTES_CACHE_PATH = "saved_models/notes.pkl"
PITCHNAMES_CACHE_PATH = "saved_models/pitchnames.pkl"

MODEL_PATH = "saved_models/music_model.keras"
CHECKPOINT_PATH = "saved_models/checkpoint.keras"

GAN_GENERATOR_BEST_PATH = "saved_models/gan_generator_best.keras"
GAN_GENERATOR_FINAL_PATH = "saved_models/gan_generator_final.keras"
GAN_DISCRIMINATOR_PATH = "saved_models/gan_discriminator_final.keras"
GAN_HISTORY_PATH = "saved_models/gan_history.pkl"

OUTPUT_MIDI_PATH = "output/generated_music.mid"
OUTPUT_WAV_PATH = "output/generated_music.wav"


def save_training_data(notes, pitchnames):
    os.makedirs("saved_models", exist_ok=True)
    with open(NOTES_CACHE_PATH, "wb") as f:
        pickle.dump(notes, f)
    with open(PITCHNAMES_CACHE_PATH, "wb") as f:
        pickle.dump(pitchnames, f)


def load_training_data():
    if not os.path.exists(NOTES_CACHE_PATH) or not os.path.exists(PITCHNAMES_CACHE_PATH):
        return None, None
    with open(NOTES_CACHE_PATH, "rb") as f:
        notes = pickle.load(f)
    with open(PITCHNAMES_CACHE_PATH, "rb") as f:
        pitchnames = pickle.load(f)
    return notes, pitchnames


def is_lstm_trained() -> bool:
    return os.path.exists(MODEL_PATH) or os.path.exists(CHECKPOINT_PATH)


def is_gan_trained() -> bool:
    return os.path.exists(GAN_GENERATOR_BEST_PATH) or os.path.exists(GAN_GENERATOR_FINAL_PATH)


def is_model_trained() -> bool:
    return is_lstm_trained() or is_gan_trained()


def get_model_path() -> str:
    if os.path.exists(MODEL_PATH):
        return MODEL_PATH
    if os.path.exists(CHECKPOINT_PATH):
        return CHECKPOINT_PATH
    return None


def get_gan_generator_path() -> str:
    if os.path.exists(GAN_GENERATOR_BEST_PATH):
        return GAN_GENERATOR_BEST_PATH
    if os.path.exists(GAN_GENERATOR_FINAL_PATH):
        return GAN_GENERATOR_FINAL_PATH
    return None


def save_uploaded_midi(uploaded_file) -> str:
    """Save a Streamlit UploadedFile to a temp file and return the path."""
    suffix = ".mid" if uploaded_file.name.lower().endswith(".mid") else ".midi"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(uploaded_file.getbuffer())
    tmp.close()
    return tmp.name


def format_note_count(n: int) -> str:
    if n >= 1000:
        return f"{n:,}"
    return str(n)


def history_to_dict(history) -> dict:
    """Convert Keras History to a plain dict."""
    return {k: [float(v) for v in vals] for k, vals in history.history.items()}


def get_loss_trend(loss_list: list[float]) -> str:
    if len(loss_list) < 2:
        return "—"
    delta = loss_list[-1] - loss_list[0]
    pct = abs(delta) / (loss_list[0] + 1e-10) * 100
    arrow = "↓" if delta < 0 else "↑"
    return f"{arrow} {pct:.1f}%"
