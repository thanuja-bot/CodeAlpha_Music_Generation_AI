"""
LSTM Music Generation Model
Defines, trains, saves, and loads the deep learning model.
"""

import os
import numpy as np


def create_lstm_model(n_vocab: int, sequence_length: int = 100):
    """
    Build and compile a stacked LSTM model for music generation.
    Args:
        n_vocab: vocabulary size (number of unique notes/chords)
        sequence_length: length of input sequences
    Returns:
        Compiled Keras model
    """
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization, Activation
    from tensorflow.keras.optimizers import RMSprop

    model = Sequential([
        LSTM(512, input_shape=(sequence_length, 1), return_sequences=True),
        Dropout(0.3),
        LSTM(512, return_sequences=False),
        Dropout(0.3),
        Dense(256),
        BatchNormalization(),
        Activation("relu"),
        Dropout(0.3),
        Dense(n_vocab, activation="softmax"),
    ])

    model.compile(
        loss="categorical_crossentropy",
        optimizer=RMSprop(learning_rate=0.001),
        metrics=["accuracy"],
    )
    return model


def create_callbacks(checkpoint_path: str, log_dir: str = None):
    """Create training callbacks for checkpoint saving and early stopping."""
    from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau

    os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True) if os.path.dirname(checkpoint_path) else None

    callbacks = [
        ModelCheckpoint(
            filepath=checkpoint_path,
            monitor="loss",
            save_best_only=True,
            verbose=0,
        ),
        EarlyStopping(monitor="loss", patience=10, verbose=0, restore_best_weights=True),
        ReduceLROnPlateau(monitor="loss", factor=0.5, patience=5, min_lr=1e-6, verbose=0),
    ]
    return callbacks


def train_model(model, network_input, network_output, epochs: int = 50,
                batch_size: int = 64, checkpoint_path: str = "saved_models/checkpoint.keras",
                streamlit_callback=None):
    """
    Train the LSTM model.
    Args:
        model: Compiled Keras model
        network_input: (samples, seq_len, 1) normalized input array
        network_output: one-hot encoded output array
        epochs: number of training epochs
        batch_size: mini-batch size
        checkpoint_path: path for saving best weights
        streamlit_callback: optional callable(epoch, logs) for Streamlit progress
    Returns:
        Training history object
    """
    from tensorflow.keras.callbacks import LambdaCallback

    callbacks = create_callbacks(checkpoint_path)

    if streamlit_callback is not None:
        st_cb = LambdaCallback(on_epoch_end=lambda epoch, logs: streamlit_callback(epoch, logs))
        callbacks.append(st_cb)

    history = model.fit(
        network_input,
        network_output,
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=0,
    )
    return history


def save_model(model, filepath: str):
    """Save the Keras model to disk."""
    os.makedirs(os.path.dirname(filepath), exist_ok=True) if os.path.dirname(filepath) else None
    model.save(filepath)


def load_saved_model(filepath: str):
    """Load a Keras model from disk."""
    from tensorflow.keras.models import load_model as keras_load
    return keras_load(filepath)
