"""
Piano Roll Visualization
Renders a list of piano-roll events (from generate.notes_to_piano_roll_data)
as a colour-coded Matplotlib figure suitable for embedding in Streamlit.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import MultipleLocator


PC_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
BLACK_KEYS = {1, 3, 6, 8, 10}

PC_COLORS = [
    "#E63946",
    "#E07540",
    "#E8A838",
    "#6DBF67",
    "#3CB371",
    "#4ECDC4",
    "#45B7D1",
    "#6C63FF",
    "#9B59B6",
    "#E91E8C",
    "#FF6B9D",
    "#C0392B",
]


def _pitch_label(midi: int) -> str:
    pc = midi % 12
    octave = midi // 12 - 1
    return f"{PC_NAMES[pc]}{octave}"


def render_piano_roll(
    events: list[dict],
    max_notes: int = 120,
    fig_width: float = 14,
    fig_height: float = 6,
    note_range: tuple[int, int] | None = None,
    show_keyboard: bool = True,
    title: str = "Piano Roll",
) -> plt.Figure:
    """
    Render a piano-roll figure.

    Args:
        events:       List of dicts from notes_to_piano_roll_data()
        max_notes:    Maximum number of time steps to display
        fig_width:    Figure width in inches
        fig_height:   Figure height in inches
        note_range:   (low_midi, high_midi) pitch window. Auto-detected if None.
        show_keyboard: Draw a mini keyboard strip on the left y-axis
        title:        Chart title

    Returns:
        matplotlib Figure
    """
    if not events:
        fig, ax = plt.subplots(figsize=(fig_width, fig_height))
        ax.text(0.5, 0.5, "No notes to display", ha="center", va="center",
                transform=ax.transAxes, color="white", fontsize=14)
        ax.set_facecolor("#1A1C2A")
        fig.patch.set_facecolor("#1A1C2A")
        return fig

    display_events = events[:max_notes * 4]

    pitches = [e["pitch"] for e in display_events]
    times = [e["time"] for e in display_events]

    if note_range is None:
        p_min = max(0, min(pitches) - 3)
        p_max = min(127, max(pitches) + 3)
        p_min = (p_min // 12) * 12
        p_max = ((p_max // 12) + 1) * 12
    else:
        p_min, p_max = note_range

    t_max = max(times) + events[0]["duration"] + 0.5

    keyboard_width = 1.8 if show_keyboard else 0
    fig = plt.figure(figsize=(fig_width, fig_height), facecolor="#0E1117")

    if show_keyboard:
        gs = fig.add_gridspec(1, 2, width_ratios=[keyboard_width, fig_width - keyboard_width],
                               wspace=0.0)
        ax_keys = fig.add_subplot(gs[0, 0])
        ax = fig.add_subplot(gs[0, 1])
    else:
        ax = fig.add_subplot(111)
        ax_keys = None

    ax.set_facecolor("#0E1117")
    ax.set_xlim(0, t_max)
    ax.set_ylim(p_min - 0.5, p_max + 0.5)

    for octave_start in range((p_min // 12) * 12, p_max + 1, 12):
        ax.axhline(octave_start - 0.5, color="#333355", linewidth=0.8, zorder=0)

    for pc in BLACK_KEYS:
        for octave in range(p_min // 12, p_max // 12 + 1):
            midi = octave * 12 + pc
            if p_min <= midi <= p_max:
                ax.axhspan(midi - 0.5, midi + 0.5, color="#1A1C2A", alpha=0.6, zorder=0)

    beat_interval = max(1, int(t_max / 20))
    for beat in np.arange(0, t_max, beat_interval):
        ax.axvline(beat, color="#2A2A4A", linewidth=0.6, zorder=0)

    note_height = 0.75

    seen_times = {}
    for event in display_events:
        t = event["time"]
        seen_times[t] = seen_times.get(t, 0) + 1

    for event in display_events:
        t = event["time"]
        p = event["pitch"]
        dur = event["duration"]
        pc = event["pitch_class"]
        is_chord = event["is_chord"]

        color = PC_COLORS[pc]
        alpha = 0.72 if is_chord else 0.92
        edge_color = "#FFFFFF22"

        rect = FancyBboxPatch(
            (t + 0.02, p - note_height / 2),
            max(dur - 0.06, 0.1),
            note_height,
            boxstyle="round,pad=0.04",
            facecolor=color,
            edgecolor=edge_color,
            linewidth=0.5,
            alpha=alpha,
            zorder=2,
        )
        ax.add_patch(rect)

    yticks = list(range(p_min, p_max + 1, 1))
    ylabels = []
    for m in yticks:
        pc = m % 12
        if pc == 0:
            ylabels.append(_pitch_label(m))
        else:
            ylabels.append("")

    ax.set_yticks(yticks)
    ax.set_yticklabels(ylabels, fontsize=7, color="#CCCCCC")
    ax.tick_params(axis="y", length=0, pad=4)

    ax.set_xlabel("Beat", color="#AAAAAA", fontsize=9)
    ax.set_title(title, color="#FFFFFF", fontsize=11, pad=8)
    ax.tick_params(axis="x", colors="#AAAAAA", labelsize=8)

    for spine in ax.spines.values():
        spine.set_edgecolor("#333355")

    if show_keyboard and ax_keys is not None:
        ax_keys.set_facecolor("#0E1117")
        ax_keys.set_xlim(0, 1)
        ax_keys.set_ylim(p_min - 0.5, p_max + 0.5)
        ax_keys.set_xticks([])
        ax_keys.set_yticks([])
        for spine in ax_keys.spines.values():
            spine.set_visible(False)

        for midi in range(p_min, p_max + 1):
            pc = midi % 12
            is_black = pc in BLACK_KEYS
            key_color = "#1E1E2E" if is_black else "#DDEEFF"
            text_color = "#AAAACC" if is_black else "#222233"
            label = _pitch_label(midi) if pc == 0 else ""

            key_rect = mpatches.FancyBboxPatch(
                (0.05, midi - 0.42), 0.88, 0.84,
                boxstyle="round,pad=0.02",
                facecolor=key_color,
                edgecolor="#333355",
                linewidth=0.4,
                zorder=2,
            )
            ax_keys.add_patch(key_rect)

            if label:
                ax_keys.text(0.5, midi, label, ha="center", va="center",
                             fontsize=6.5, color=text_color, fontweight="bold", zorder=3)

    legend_patches = []
    used_pcs = sorted(set(e["pitch_class"] for e in display_events))
    for pc in used_pcs:
        legend_patches.append(
            mpatches.Patch(facecolor=PC_COLORS[pc], label=PC_NAMES[pc], alpha=0.9)
        )

    ax.legend(
        handles=legend_patches,
        loc="upper right",
        ncol=min(len(legend_patches), 6),
        fontsize=7,
        framealpha=0.3,
        facecolor="#1A1C2A",
        edgecolor="#333355",
        labelcolor="white",
    )

    plt.tight_layout(pad=0.5)
    return fig


def render_pitch_class_histogram(events: list[dict]) -> plt.Figure:
    """
    Render a bar chart showing the distribution of pitch classes in the generated piece.
    """
    from collections import Counter

    if not events:
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.set_facecolor("#1A1C2A")
        fig.patch.set_facecolor("#0E1117")
        return fig

    pc_counts = Counter(e["pitch_class"] for e in events)
    pcs = list(range(12))
    counts = [pc_counts.get(pc, 0) for pc in pcs]
    total = sum(counts) or 1
    percentages = [c / total * 100 for c in counts]

    fig, ax = plt.subplots(figsize=(10, 3))
    fig.patch.set_facecolor("#0E1117")
    ax.set_facecolor("#0E1117")

    bars = ax.bar(
        PC_NAMES, percentages,
        color=[PC_COLORS[pc] for pc in pcs],
        edgecolor="#333355", linewidth=0.5, alpha=0.88,
    )

    for bar, pct in zip(bars, percentages):
        if pct > 1:
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.3,
                f"{pct:.1f}%",
                ha="center", va="bottom", fontsize=7, color="#CCCCCC",
            )

    ax.set_title("Pitch Class Distribution", color="#FFFFFF", fontsize=10, pad=6)
    ax.set_xlabel("Pitch Class", color="#AAAAAA", fontsize=9)
    ax.set_ylabel("% of Notes", color="#AAAAAA", fontsize=9)
    ax.tick_params(colors="#AAAAAA", labelsize=8)
    ax.set_ylim(0, max(percentages) * 1.25 if percentages else 10)
    ax.grid(axis="y", color="#2A2A4A", linewidth=0.6, alpha=0.7)

    for spine in ax.spines.values():
        spine.set_edgecolor("#333355")

    plt.tight_layout(pad=0.5)
    return fig
