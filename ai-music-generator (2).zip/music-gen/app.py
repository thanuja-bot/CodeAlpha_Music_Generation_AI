"""
AI Music Generation App
Streamlit UI supporting two model architectures:
  • LSTM  — autoregressive sequence prediction (structured, melodic)
  • GAN   — adversarial generator/discriminator (experimental, varied)
"""

import io
import os
import numpy as np
import streamlit as st

from preprocess import parse_midi_file, prepare_sequences, get_note_statistics
from model import create_lstm_model, train_model, save_model, load_saved_model
from gan_model import (
    build_generator, build_discriminator, build_gan, compile_models,
    prepare_gan_sequences, train_gan,
    gan_generate_notes, load_gan_generator,
    save_gan_history, load_gan_history,
)
from generate import generate_notes, notes_to_midi, synthesize_preview_audio, notes_to_piano_roll_data
from piano_roll import render_piano_roll, render_pitch_class_histogram
from utils import (
    NOTES_CACHE_PATH, PITCHNAMES_CACHE_PATH,
    MODEL_PATH, CHECKPOINT_PATH,
    GAN_GENERATOR_BEST_PATH, GAN_GENERATOR_FINAL_PATH,
    GAN_DISCRIMINATOR_PATH, GAN_HISTORY_PATH,
    OUTPUT_MIDI_PATH, OUTPUT_WAV_PATH,
    save_training_data, load_training_data,
    is_lstm_trained, is_gan_trained,
    get_model_path, get_gan_generator_path,
    save_uploaded_midi, format_note_count,
    history_to_dict, get_loss_trend,
)

os.makedirs("saved_models", exist_ok=True)
os.makedirs("output", exist_ok=True)
os.makedirs("sample_midi", exist_ok=True)

st.set_page_config(
    page_title="AI Music Generator",
    page_icon="🎵",
    layout="wide",
    initial_sidebar_state="expanded",
)


def init_session_state():
    defaults = {
        "notes": None,
        "pitchnames": None,
        "n_vocab": 0,
        "network_input": None,
        "network_output": None,
        "network_input_raw": None,
        "model": None,
        "training_history": None,
        "gan_generator": None,
        "gan_training_history": None,
        "model_type": "LSTM",
        "generated_notes": None,
        "midi_ready": False,
        "wav_ready": False,
        "training_log": [],
        "upload_count": 0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


init_session_state()


def try_load_cached_data():
    if st.session_state.notes is None:
        notes, pitchnames = load_training_data()
        if notes and pitchnames:
            st.session_state.notes = notes
            st.session_state.pitchnames = pitchnames
            st.session_state.n_vocab = len(pitchnames)

    if st.session_state.model is None and is_lstm_trained():
        try:
            st.session_state.model = load_saved_model(get_model_path())
        except Exception:
            pass

    if st.session_state.gan_generator is None and is_gan_trained():
        try:
            st.session_state.gan_generator = load_gan_generator(get_gan_generator_path())
        except Exception:
            pass

    if st.session_state.gan_training_history is None and os.path.exists(GAN_HISTORY_PATH):
        try:
            st.session_state.gan_training_history = load_gan_history(GAN_HISTORY_PATH)
        except Exception:
            pass


try_load_cached_data()


with st.sidebar:
    st.title("🎵 AI Music Generator")
    st.markdown("---")

    st.subheader("Model Architecture")
    model_type = st.radio(
        "Select model",
        ["LSTM", "GAN"],
        index=0 if st.session_state.model_type == "LSTM" else 1,
        help=(
            "**LSTM** — autoregressive; learns note-by-note transitions. "
            "Great for melodic, structured output.\n\n"
            "**GAN** — adversarial; generator vs. discriminator. "
            "More experimental and varied output."
        ),
        horizontal=True,
    )
    st.session_state.model_type = model_type

    if model_type == "LSTM":
        st.caption("Stacked LSTM · temperature sampling · best-checkpoint save")
    else:
        st.caption("Bidirectional LSTM Generator + Discriminator · label smoothing")

    st.markdown("---")

    st.subheader("Status")
    data_loaded = st.session_state.notes is not None
    lstm_ready = st.session_state.model is not None
    gan_ready = st.session_state.gan_generator is not None
    music_ready = st.session_state.midi_ready

    st.markdown(f"{'✅' if data_loaded else '⬜'} Dataset loaded")
    if data_loaded:
        st.caption(
            f"{format_note_count(len(st.session_state.notes))} notes · "
            f"{st.session_state.n_vocab} unique"
        )
    st.markdown(f"{'✅' if lstm_ready else '⬜'} LSTM trained")
    st.markdown(f"{'✅' if gan_ready else '⬜'} GAN trained")
    st.markdown(f"{'✅' if music_ready else '⬜'} Music generated")

    st.markdown("---")
    st.subheader("Settings")

    sequence_length = st.slider(
        "Sequence length", 25, 200, 100, 5,
        help="Input window size (notes). Applies to both LSTM and GAN."
    )
    epochs = st.slider(
        "Training epochs", 10, 300,
        50 if model_type == "LSTM" else 100, 10,
        help="GAN typically needs more epochs than LSTM for stable output."
    )
    batch_size = st.selectbox("Batch size", [32, 64, 128], index=1)
    num_notes_gen = st.slider("Notes to generate", 50, 500, 200, 25)
    temperature = st.slider(
        "Creativity (temperature)", 0.2, 2.0, 1.0, 0.1,
        help="Lower = more predictable. Higher = more experimental."
    )

    if model_type == "GAN":
        st.markdown("**GAN-specific**")
        latent_dim = st.slider(
            "Noise dimension (latent)", 50, 300, 100, 10,
            help="Size of the random noise vector fed to the generator."
        )
        lr_d = st.select_slider(
            "Discriminator LR",
            options=[0.00005, 0.0001, 0.0002, 0.0005],
            value=0.0002,
        )
        lr_g = st.select_slider(
            "Generator LR",
            options=[0.00005, 0.0001, 0.0002, 0.0005],
            value=0.0002,
        )
    else:
        latent_dim = 100
        lr_d = lr_g = 0.0002


st.title("🎵 AI Music Generator")
st.markdown(
    "Upload MIDI files · train an **LSTM** or **GAN** model · "
    "generate original compositions · download or preview."
)
st.markdown("---")


tab1, tab2, tab3, tab4 = st.tabs(
    ["📂 Upload Dataset", "🧠 Train Model", "🎼 Generate Music", "ℹ️ About"]
)


with tab1:
    st.header("Upload MIDI Dataset")
    st.markdown(
        "Upload one or more `.mid` / `.midi` files. "
        "Both LSTM and GAN share the same processed dataset — "
        "you only need to upload once."
    )

    col_upload, col_sample = st.columns([2, 1])

    with col_upload:
        uploaded_files = st.file_uploader(
            "Upload MIDI Files",
            type=["mid", "midi"],
            accept_multiple_files=True,
            key=f"uploader_{st.session_state.upload_count}",
        )

    with col_sample:
        st.markdown("**No MIDI files?**")
        st.markdown(
            "Download free datasets from:\n"
            "- [MIDI World](http://www.midiworld.com)\n"
            "- [Classical Archives](https://www.classicalarchives.com)\n"
            "- [Josquin Research Project](https://josquin.stanford.edu)"
        )

    if uploaded_files:
        st.markdown(f"**{len(uploaded_files)} file(s) selected**")

        if st.button("Process MIDI Files", type="primary", use_container_width=True):
            progress_bar = st.progress(0, text="Parsing MIDI files…")
            status_text = st.empty()
            temp_paths = []

            try:
                for uf in uploaded_files:
                    temp_paths.append(save_uploaded_midi(uf))

                parsed_notes, errors = [], []

                for i, (tp, uf) in enumerate(zip(temp_paths, uploaded_files)):
                    status_text.text(f"Parsing {uf.name} ({i+1}/{len(uploaded_files)})…")
                    try:
                        parsed_notes.extend(parse_midi_file(tp))
                    except Exception as e:
                        errors.append(f"{uf.name}: {e}")
                    progress_bar.progress(
                        (i + 1) / len(uploaded_files),
                        text=f"Processed {i+1}/{len(uploaded_files)} files",
                    )

                for err in errors:
                    st.warning(f"⚠️ {err}")

                if parsed_notes:
                    pitchnames = sorted(set(parsed_notes))
                    st.session_state.notes = parsed_notes
                    st.session_state.pitchnames = pitchnames
                    st.session_state.n_vocab = len(pitchnames)
                    st.session_state.network_input = None
                    st.session_state.network_output = None
                    st.session_state.network_input_raw = None
                    st.session_state.model = None
                    st.session_state.gan_generator = None
                    st.session_state.training_history = None
                    st.session_state.gan_training_history = None
                    st.session_state.midi_ready = False
                    st.session_state.wav_ready = False
                    save_training_data(parsed_notes, pitchnames)
                    progress_bar.progress(1.0, text="Done!")
                    st.success(
                        f"✅ Parsed **{format_note_count(len(parsed_notes))} notes** "
                        f"from {len(uploaded_files) - len(errors)} file(s)."
                    )
                else:
                    st.error("No notes could be extracted. Please check your MIDI files.")

            except Exception as e:
                st.error(f"Error processing files: {e}")
            finally:
                for tp in temp_paths:
                    try:
                        os.unlink(tp)
                    except Exception:
                        pass

    if st.session_state.notes:
        st.markdown("---")
        st.subheader("Dataset Statistics")
        stats = get_note_statistics(st.session_state.notes)
        c1, c2, c3 = st.columns(3)
        c1.metric("Total Notes", format_note_count(stats["total_notes"]))
        c2.metric("Unique Tokens", stats["unique_notes"])
        c3.metric("Min recommended", "500+ notes")

        with st.expander("Most Common Notes / Chords"):
            for note_name, count in stats["most_common"]:
                st.text(f"  {note_name:<20} {count:>6} occurrences")


with tab2:
    st.header("Train Model")

    if not st.session_state.notes:
        st.info("👈 Upload and process MIDI files first in the **Upload Dataset** tab.")
    else:
        active_type = st.session_state.model_type

        st.markdown(
            f"Training **{active_type}** model · "
            f"{format_note_count(len(st.session_state.notes))} notes · "
            f"{st.session_state.n_vocab} unique tokens · "
            f"seq length **{sequence_length}** · epochs **{epochs}**"
        )

        if active_type == "LSTM":
            col_train, col_info = st.columns([1, 1])
            with col_info:
                st.info(
                    "The LSTM learns note-by-note transitions. "
                    "It auto-saves the best checkpoint, so you can stop early. "
                    "Recommended: 50–150 epochs."
                )
            with col_train:
                train_btn = st.button(
                    "🚀 Train LSTM", type="primary", use_container_width=True
                )

            if train_btn:
                try:
                    prep_bar = st.progress(0, text="Preparing sequences…")
                    net_in, net_out, pitchnames, n_vocab, net_in_raw = prepare_sequences(
                        st.session_state.notes, sequence_length
                    )
                    st.session_state.network_input = net_in
                    st.session_state.network_output = net_out
                    st.session_state.network_input_raw = net_in_raw
                    st.session_state.pitchnames = pitchnames
                    st.session_state.n_vocab = n_vocab
                    prep_bar.progress(1.0, text=f"Prepared {len(net_in):,} sequences.")
                    st.markdown(f"**{len(net_in):,} training sequences** prepared.")

                    model = create_lstm_model(n_vocab, sequence_length)
                    epoch_bar = st.progress(0, text="Training…")
                    loss_display = st.empty()
                    log_exp = st.expander("Training log", expanded=False)
                    loss_history = []

                    def lstm_epoch_cb(epoch, logs):
                        loss = logs.get("loss", 0.0)
                        acc = logs.get("accuracy", 0.0)
                        loss_history.append(loss)
                        epoch_bar.progress(
                            min((epoch + 1) / epochs, 1.0),
                            text=f"Epoch {epoch+1}/{epochs} — loss: {loss:.4f}",
                        )
                        loss_display.markdown(
                            f"**Loss:** `{loss:.4f}` &nbsp;|&nbsp; "
                            f"**Acc:** `{acc:.4f}` &nbsp;|&nbsp; "
                            f"**Trend:** {get_loss_trend(loss_history)}"
                        )
                        st.session_state.training_log.append(
                            f"E{epoch+1:03d} loss={loss:.4f} acc={acc:.4f}"
                        )

                    history = train_model(
                        model, net_in, net_out,
                        epochs=epochs, batch_size=batch_size,
                        checkpoint_path=CHECKPOINT_PATH,
                        streamlit_callback=lstm_epoch_cb,
                    )
                    save_model(model, MODEL_PATH)
                    st.session_state.model = model
                    st.session_state.training_history = history_to_dict(history)

                    epoch_bar.progress(1.0, text="Training complete!")
                    final_loss = history.history["loss"][-1]
                    st.success(f"✅ LSTM trained · final loss **{final_loss:.4f}**")

                    with log_exp:
                        for line in st.session_state.training_log[-30:]:
                            st.text(line)

                except Exception as e:
                    st.error(f"LSTM training failed: {e}")
                    st.exception(e)

            if st.session_state.training_history:
                st.markdown("---")
                st.subheader("LSTM Training History")
                import matplotlib.pyplot as plt

                loss_vals = st.session_state.training_history.get("loss", [])
                acc_vals = st.session_state.training_history.get("accuracy", [])
                fig, axes = plt.subplots(1, 2, figsize=(12, 3))
                axes[0].plot(loss_vals, color="#6C63FF", linewidth=2)
                axes[0].set_title("Loss")
                axes[0].set_xlabel("Epoch")
                axes[0].grid(True, alpha=0.3)
                axes[1].plot(acc_vals, color="#2ca02c", linewidth=2)
                axes[1].set_title("Accuracy")
                axes[1].set_xlabel("Epoch")
                axes[1].grid(True, alpha=0.3)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close(fig)

        else:
            col_train, col_info = st.columns([1, 1])
            with col_info:
                st.info(
                    "The GAN trains a **Generator** (makes music) against a **Discriminator** "
                    "(spots fakes). GAN training is inherently noisier than LSTM — "
                    "watch for the generator loss decreasing over time. "
                    "Recommended: 100–200 epochs with latent dim 100."
                )
            with col_train:
                gan_btn = st.button(
                    "🚀 Train GAN", type="primary", use_container_width=True
                )

            if gan_btn:
                try:
                    prep_bar = st.progress(0, text="Preparing one-hot sequences…")
                    real_seqs, pitchnames, n_vocab, _ = prepare_gan_sequences(
                        st.session_state.notes, sequence_length
                    )
                    st.session_state.pitchnames = pitchnames
                    st.session_state.n_vocab = n_vocab
                    prep_bar.progress(
                        1.0, text=f"Prepared {len(real_seqs):,} sequences ({n_vocab} vocab)."
                    )
                    st.markdown(
                        f"**{len(real_seqs):,} training sequences** · "
                        f"latent dim **{latent_dim}** · seq length **{sequence_length}**"
                    )

                    generator = build_generator(latent_dim, sequence_length, n_vocab)
                    discriminator = build_discriminator(sequence_length, n_vocab)
                    gan = build_gan(generator, discriminator)
                    compile_models(generator, discriminator, gan, lr_d=lr_d, lr_g=lr_g)

                    epoch_bar = st.progress(0, text="Training GAN…")
                    metrics_display = st.empty()
                    chart_placeholder = st.empty()

                    col_d, col_g = st.columns(2)
                    d_loss_display = col_d.empty()
                    g_loss_display = col_g.empty()

                    gan_log = []

                    def gan_epoch_cb(epoch, entry):
                        gan_log.append(entry)
                        epoch_bar.progress(
                            min((epoch + 1) / epochs, 1.0),
                            text=(
                                f"Epoch {epoch+1}/{epochs} · "
                                f"D loss: {entry['d_loss']:.4f} · "
                                f"G loss: {entry['g_loss']:.4f}"
                            ),
                        )
                        d_loss_display.metric(
                            "Discriminator Loss",
                            f"{entry['d_loss']:.4f}",
                            delta=f"acc {entry['d_acc']*100:.1f}%",
                        )
                        g_loss_display.metric(
                            "Generator Loss",
                            f"{entry['g_loss']:.4f}",
                        )

                    history_list = train_gan(
                        generator, discriminator, gan,
                        real_seqs=real_seqs,
                        latent_dim=latent_dim,
                        epochs=epochs,
                        batch_size=batch_size,
                        streamlit_callback=gan_epoch_cb,
                        save_dir="saved_models",
                    )

                    save_gan_history(history_list, GAN_HISTORY_PATH)
                    st.session_state.gan_generator = generator
                    st.session_state.gan_training_history = history_list
                    st.session_state.network_input_raw = None

                    epoch_bar.progress(1.0, text="GAN training complete!")
                    final_g = history_list[-1]["g_loss"] if history_list else 0
                    st.success(
                        f"✅ GAN trained · generator saved · "
                        f"final G loss **{final_g:.4f}**"
                    )

                except Exception as e:
                    st.error(f"GAN training failed: {e}")
                    st.exception(e)

            if st.session_state.gan_training_history:
                st.markdown("---")
                st.subheader("GAN Training History")
                import matplotlib.pyplot as plt

                history_list = st.session_state.gan_training_history
                ep = [e["epoch"] for e in history_list]
                d_losses = [e["d_loss"] for e in history_list]
                g_losses = [e["g_loss"] for e in history_list]
                d_accs = [e["d_acc"] * 100 for e in history_list]

                fig, axes = plt.subplots(1, 2, figsize=(12, 3))

                axes[0].plot(ep, d_losses, label="Discriminator", color="#e74c3c", linewidth=2)
                axes[0].plot(ep, g_losses, label="Generator", color="#6C63FF", linewidth=2)
                axes[0].set_title("GAN Losses")
                axes[0].set_xlabel("Epoch")
                axes[0].set_ylabel("Loss")
                axes[0].legend()
                axes[0].grid(True, alpha=0.3)

                axes[1].plot(ep, d_accs, color="#f39c12", linewidth=2)
                axes[1].axhline(50, color="gray", linestyle="--", alpha=0.5, label="50% baseline")
                axes[1].set_title("Discriminator Accuracy")
                axes[1].set_xlabel("Epoch")
                axes[1].set_ylabel("Accuracy (%)")
                axes[1].legend()
                axes[1].grid(True, alpha=0.3)

                plt.tight_layout()
                st.pyplot(fig)
                plt.close(fig)

                st.caption(
                    "Healthy GAN training: discriminator accuracy hovers around 50–70% "
                    "as the generator improves. Generator loss trending downward is a good sign."
                )


with tab3:
    st.header("Generate Music")

    active_type = st.session_state.model_type
    model_available = (
        st.session_state.model is not None if active_type == "LSTM"
        else st.session_state.gan_generator is not None
    )
    data_available = st.session_state.notes is not None

    if not data_available:
        st.info("👈 Upload and process MIDI files first in the **Upload Dataset** tab.")
    elif not model_available:
        trained_other = (
            st.session_state.gan_generator is not None
            if active_type == "LSTM"
            else st.session_state.model is not None
        )
        other_name = "GAN" if active_type == "LSTM" else "LSTM"
        if trained_other:
            st.warning(
                f"The **{active_type}** model hasn't been trained yet, "
                f"but you have a trained **{other_name}** model. "
                f"Switch to **{other_name}** in the sidebar or train the {active_type} first."
            )
        else:
            st.info(f"👈 Train the **{active_type}** model first in the **Train Model** tab.")
    else:
        st.markdown(
            f"**{active_type}** model ready · "
            f"vocab **{st.session_state.n_vocab}** tokens · "
            f"generating **{num_notes_gen}** notes · "
            f"temperature **{temperature}**"
        )
        if active_type == "GAN":
            st.markdown(f"Noise dimension: **{latent_dim}** · "
                        f"seq length: **{sequence_length}**")

        col_gen, col_info = st.columns([1, 1])
        with col_info:
            if active_type == "LSTM":
                st.info(
                    "LSTM generation is autoregressive — each note is conditioned on the "
                    "previous sequence. Expect melodically coherent output."
                )
            else:
                st.info(
                    "GAN generation samples random noise and passes it through the generator. "
                    "Each run produces a different result from the same model."
                )

        with col_gen:
            gen_btn = st.button("🎼 Generate Music", type="primary", use_container_width=True)

        if gen_btn:
            try:
                gen_bar = st.progress(0, text="Starting generation…")

                if active_type == "LSTM":
                    if st.session_state.network_input_raw is None:
                        gen_bar.progress(0.1, text="Preparing sequences…")
                        _, _, pitchnames, n_vocab, net_in_raw = prepare_sequences(
                            st.session_state.notes, sequence_length
                        )
                        st.session_state.network_input_raw = net_in_raw
                        st.session_state.pitchnames = pitchnames
                        st.session_state.n_vocab = n_vocab

                    gen_bar.progress(0.4, text="Generating with LSTM…")
                    generated = generate_notes(
                        st.session_state.model,
                        st.session_state.network_input_raw,
                        st.session_state.pitchnames,
                        st.session_state.n_vocab,
                        num_notes=num_notes_gen,
                        temperature=temperature,
                    )
                else:
                    gen_bar.progress(0.4, text="Generating with GAN…")
                    generated = gan_generate_notes(
                        st.session_state.gan_generator,
                        st.session_state.pitchnames,
                        st.session_state.n_vocab,
                        num_notes=num_notes_gen,
                        latent_dim=latent_dim,
                        temperature=temperature,
                    )

                st.session_state.generated_notes = generated
                gen_bar.progress(0.7, text="Converting to MIDI…")
                notes_to_midi(generated, OUTPUT_MIDI_PATH)
                st.session_state.midi_ready = True

                gen_bar.progress(0.85, text="Synthesizing audio preview…")
                wav_ok = synthesize_preview_audio(OUTPUT_MIDI_PATH, OUTPUT_WAV_PATH)
                st.session_state.wav_ready = wav_ok

                gen_bar.progress(1.0, text="Done!")
                st.success(
                    f"✅ [{active_type}] Generated **{len(generated)} notes** · MIDI saved!"
                )

            except Exception as e:
                st.error(f"Generation failed: {e}")
                st.exception(e)

        if st.session_state.midi_ready:
            st.markdown("---")
            st.subheader("Generated Music")

            col_dl, col_audio = st.columns([1, 1])

            with col_dl:
                st.markdown("### Download")
                try:
                    with open(OUTPUT_MIDI_PATH, "rb") as f:
                        midi_bytes = f.read()
                    st.download_button(
                        label="⬇️ Download MIDI File",
                        data=midi_bytes,
                        file_name="generated_music.mid",
                        mime="audio/midi",
                        use_container_width=True,
                        type="primary",
                    )
                    st.caption("Open in any DAW or media player for full quality.")
                except Exception as e:
                    st.error(f"Could not read MIDI file: {e}")

            with col_audio:
                st.markdown("### Audio Preview")
                if st.session_state.wav_ready and os.path.exists(OUTPUT_WAV_PATH):
                    try:
                        with open(OUTPUT_WAV_PATH, "rb") as f:
                            wav_bytes = f.read()
                        st.audio(wav_bytes, format="audio/wav")
                        st.caption("Sine-wave synthesis preview.")
                    except Exception as e:
                        st.warning(f"Could not load audio: {e}")
                else:
                    st.info("Download the MIDI file for full quality playback.")

            st.markdown("---")
            st.subheader("Piano Roll Visualization")
            st.caption(
                "Each coloured bar is one note or chord note. "
                "Pitch runs bottom-to-top; time left-to-right. "
                "Colour = pitch class (C red, D orange, …). "
                "Semi-transparent bars indicate chord notes."
            )

            if st.session_state.generated_notes:
                roll_events = notes_to_piano_roll_data(st.session_state.generated_notes)

                if roll_events:
                    roll_col, ctrl_col = st.columns([4, 1])

                    with ctrl_col:
                        st.markdown("**View controls**")
                        max_display = st.slider(
                            "Notes shown",
                            min_value=25,
                            max_value=min(500, len(st.session_state.generated_notes)),
                            value=min(120, len(st.session_state.generated_notes)),
                            step=25,
                            help="How many notes to include in the piano roll.",
                        )
                        show_keyboard = st.checkbox("Show keyboard", value=True)

                        all_pitches = [e["pitch"] for e in roll_events]
                        min_p = max(0, min(all_pitches) - 3)
                        max_p = min(127, max(all_pitches) + 3)
                        pitch_range = st.slider(
                            "Pitch window (MIDI)",
                            min_value=0,
                            max_value=127,
                            value=(
                                (min_p // 12) * 12,
                                min(127, ((max_p // 12) + 1) * 12),
                            ),
                            step=12,
                            help="MIDI pitch range displayed on the y-axis.",
                        )

                    with roll_col:
                        try:
                            fig_roll = render_piano_roll(
                                roll_events,
                                max_notes=max_display,
                                fig_width=13,
                                fig_height=5,
                                note_range=pitch_range,
                                show_keyboard=show_keyboard,
                                title=f"Piano Roll — {active_type} · {len(st.session_state.generated_notes)} notes · temp {temperature}",
                            )
                            st.pyplot(fig_roll)

                            roll_buf = io.BytesIO()
                            fig_roll.savefig(
                                roll_buf, format="png", dpi=180,
                                bbox_inches="tight", facecolor=fig_roll.get_facecolor(),
                            )
                            roll_buf.seek(0)
                            plt.close(fig_roll)

                            st.download_button(
                                label="⬇️ Save Piano Roll as PNG",
                                data=roll_buf,
                                file_name="piano_roll.png",
                                mime="image/png",
                                use_container_width=True,
                            )
                        except Exception as e:
                            st.warning(f"Piano roll render failed: {e}")

                    st.markdown("#### Pitch Class Distribution")
                    st.caption(
                        "Shows which notes (C, D, E … B) appear most in the composition — "
                        "a useful indicator of key or tonality."
                    )
                    try:
                        fig_hist = render_pitch_class_histogram(roll_events)
                        st.pyplot(fig_hist)

                        hist_buf = io.BytesIO()
                        fig_hist.savefig(
                            hist_buf, format="png", dpi=180,
                            bbox_inches="tight", facecolor=fig_hist.get_facecolor(),
                        )
                        hist_buf.seek(0)
                        plt.close(fig_hist)

                        st.download_button(
                            label="⬇️ Save Distribution Chart as PNG",
                            data=hist_buf,
                            file_name="pitch_distribution.png",
                            mime="image/png",
                            use_container_width=True,
                        )
                    except Exception as e:
                        st.warning(f"Histogram render failed: {e}")

                else:
                    st.info("No parseable notes found for visualization.")

            with st.expander("All Generated Tokens (text)"):
                if st.session_state.generated_notes:
                    for chunk in [
                        st.session_state.generated_notes[i:i+20]
                        for i in range(0, len(st.session_state.generated_notes), 20)
                    ]:
                        st.text("  ".join(n.ljust(10) for n in chunk))


with tab4:
    st.header("About this App")
    st.markdown(
        """
        ### AI Music Generator

        This app supports two deep learning architectures for symbolic music generation,
        both trained on your uploaded MIDI files.

        ---

        ## LSTM Mode

        **Best for:** Melodic, structured, genre-coherent compositions.

        | Step | Description |
        |------|-------------|
        | Preprocessing | MIDI → note/chord token stream via `music21` |
        | Sequences | Overlapping windows of `sequence_length` tokens |
        | Model | 2× stacked LSTM (512 units) + Dropout + BatchNorm |
        | Training | Cross-entropy loss, RMSprop, best-checkpoint save |
        | Generation | Autoregressive with temperature sampling |

        **Architecture diagram:**
        ```
        Input (seq_len, 1)
          ↓
        LSTM(512) → Dropout(0.3)
          ↓
        LSTM(512) → Dropout(0.3)
          ↓
        Dense(256) + BatchNorm + ReLU → Dropout(0.3)
          ↓
        Dense(n_vocab, softmax)
        ```

        ---

        ## GAN Mode

        **Best for:** Varied, experimental, less predictable output.

        The GAN pits two networks against each other:

        | Network | Role |
        |---------|------|
        | **Generator** | Takes random noise → produces a fake note sequence |
        | **Discriminator** | Classifies sequences as real (from your MIDI) or fake |

        Each trains to outwit the other, pushing the generator to produce
        increasingly realistic music patterns.

        **Architecture diagram:**
        ```
        Generator:
          Noise (latent_dim,)
            ↓
          Dense(seq_len × 64) + LeakyReLU + BatchNorm
            ↓
          Reshape(seq_len, 64)
            ↓
          BiLSTM(256) → BiLSTM(256)
            ↓
          TimeDistributed Dense(n_vocab, softmax)
            ↓
          Output: (seq_len, n_vocab)

        Discriminator:
          Input (seq_len, n_vocab)
            ↓
          BiLSTM(256) → BiLSTM(128)
            ↓
          Dense(128) + LeakyReLU → Dense(1, sigmoid)
        ```

        **Interpreting GAN training charts:**
        - Discriminator accuracy ~50% = generator is fooling it (good!)
        - Generator loss trending down = model improving
        - Discriminator loss close to 0 = generator is struggling (try more epochs)

        ---

        ## Choosing Between Them

        | | LSTM | GAN |
        |-|------|-----|
        | Output style | Structured, melodic | Varied, experimental |
        | Training stability | Very stable | Inherently noisy |
        | Epochs needed | 50–150 | 100–200 |
        | Dataset size | ≥ 500 notes | ≥ 1,000 notes |
        | Generation speed | Slower (autoregressive) | Fast (single forward pass) |

        ---

        ## Tech Stack

        | Component | Library |
        |-----------|---------|
        | Web UI | Streamlit |
        | Deep learning | TensorFlow / Keras |
        | MIDI parsing | music21, mido |
        | Numerical | NumPy, SciPy |
        | Visualization | Matplotlib |
        """
    )
