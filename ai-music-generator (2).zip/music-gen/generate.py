"""
Music Generation Module
Generates note sequences from a trained model and converts them to MIDI.
"""

import os
import random
import numpy as np
from music21 import stream, note, chord, instrument
from fractions import Fraction


def generate_notes(model, network_input_raw: list, pitchnames: list[str],
                   n_vocab: int, num_notes: int = 200,
                   temperature: float = 1.0, seed_index: int = None) -> list[str]:
    """
    Generate a sequence of notes using the trained model.
    Args:
        model: trained Keras model
        network_input_raw: list of integer-encoded input sequences (not normalized)
        pitchnames: sorted list of unique pitches
        n_vocab: vocabulary size
        num_notes: number of notes to generate
        temperature: creativity control (lower = more conservative, higher = more random)
        seed_index: index into network_input_raw to use as seed (random if None)
    Returns:
        List of generated note/chord strings
    """
    int_to_note = {num: note for num, note in enumerate(pitchnames)}

    if seed_index is None:
        seed_index = random.randint(0, len(network_input_raw) - 1)

    pattern = list(network_input_raw[seed_index])
    sequence_length = len(pattern)
    prediction_output = []

    for _ in range(num_notes):
        prediction_input = np.reshape(pattern, (1, sequence_length, 1))
        prediction_input = prediction_input / float(n_vocab)

        prediction = model.predict(prediction_input, verbose=0)[0]

        if temperature != 1.0:
            prediction = np.log(prediction + 1e-10) / temperature
            prediction = np.exp(prediction)
            prediction = prediction / prediction.sum()

        index = np.random.choice(len(prediction), p=prediction)
        result = int_to_note[index]
        prediction_output.append(result)
        pattern.append(index)
        pattern = pattern[1:]

    return prediction_output


def notes_to_midi(prediction_output: list[str], output_filepath: str,
                  tempo_bpm: int = 120, note_duration: float = 0.5):
    """
    Convert a list of note/chord strings into a MIDI file.
    Args:
        prediction_output: list of note/chord strings
        output_filepath: path to save the MIDI file
        tempo_bpm: beats per minute
        note_duration: duration of each note in quarter notes
    """
    output_notes = []
    offset = 0.0

    for pattern in prediction_output:
        if "." in pattern or pattern.isdigit():
            chord_notes = []
            for current_note in pattern.split("."):
                try:
                    n = note.Note(int(current_note))
                    n.storedInstrument = instrument.Piano()
                    chord_notes.append(n)
                except Exception:
                    pass
            if chord_notes:
                new_chord = chord.Chord(chord_notes)
                new_chord.offset = offset
                new_chord.quarterLength = note_duration
                output_notes.append(new_chord)
        else:
            try:
                new_note = note.Note(pattern)
                new_note.offset = offset
                new_note.storedInstrument = instrument.Piano()
                new_note.quarterLength = note_duration
                output_notes.append(new_note)
            except Exception:
                pass
        offset += note_duration

    midi_stream = stream.Stream(output_notes)
    os.makedirs(os.path.dirname(output_filepath), exist_ok=True) if os.path.dirname(output_filepath) else None
    midi_stream.write("midi", fp=output_filepath)
    return output_filepath


def notes_to_piano_roll_data(notes: list[str], note_duration: float = 0.5) -> list[dict]:
    """
    Convert a list of note/chord token strings into structured piano-roll events.
    Each event dict contains:
        time       — beat offset (float)
        pitch      — MIDI pitch number (int 0-127)
        duration   — note length in beats (float)
        label      — original token string
        is_chord   — True when the token came from a chord
        pitch_class — 0-11 chromatic pitch class
    Chord tokens ("0.4.7") are placed in octave 5 for display.
    Returns an empty list if no valid notes could be parsed.
    """
    from music21 import note as m21note

    PC_BASE_OCTAVE = 5
    events = []
    offset = 0.0

    for token in notes:
        if "." in token or (token.isdigit() and len(token) <= 2):
            parts = token.split(".")
            for part in parts:
                try:
                    pc = int(part) % 12
                    midi = PC_BASE_OCTAVE * 12 + pc
                    events.append({
                        "time": offset,
                        "pitch": midi,
                        "duration": note_duration,
                        "label": token,
                        "is_chord": True,
                        "pitch_class": pc,
                    })
                except ValueError:
                    pass
        else:
            try:
                n = m21note.Note(token)
                midi = n.pitch.midi
                events.append({
                    "time": offset,
                    "pitch": midi,
                    "duration": note_duration,
                    "label": token,
                    "is_chord": False,
                    "pitch_class": midi % 12,
                })
            except Exception:
                pass
        offset += note_duration

    return events


def synthesize_preview_audio(midi_filepath: str, wav_filepath: str, sample_rate: int = 22050) -> bool:
    """
    Synthesize a simple WAV preview from MIDI using basic sine wave synthesis.
    Returns True if successful, False otherwise.
    This is a lightweight preview — not a full quality render.
    """
    try:
        import mido
        import numpy as np
        import scipy.io.wavfile as wavfile

        mid = mido.MidiFile(midi_filepath)
        tempo = 500000
        ticks_per_beat = mid.ticks_per_beat

        events = []
        current_time = 0.0
        active_notes = {}

        for track in mid.tracks:
            tick_time = 0
            for msg in track:
                tick_time += msg.time
                seconds = mido.tick2second(tick_time, ticks_per_beat, tempo)
                if msg.type == "set_tempo":
                    tempo = msg.tempo
                elif msg.type == "note_on" and msg.velocity > 0:
                    events.append(("on", seconds, msg.note, msg.velocity))
                elif msg.type == "note_off" or (msg.type == "note_on" and msg.velocity == 0):
                    events.append(("off", seconds, msg.note, 0))

        if not events:
            return False

        total_duration = max(t for _, t, *_ in events) + 1.0
        audio = np.zeros(int(total_duration * sample_rate), dtype=np.float32)

        note_starts = {}
        for event in sorted(events, key=lambda x: x[1]):
            kind, t, pitch, vel = event
            freq = 440.0 * (2 ** ((pitch - 69) / 12.0))
            if kind == "on":
                note_starts[pitch] = (t, freq, vel)
            elif kind == "off" and pitch in note_starts:
                start_t, freq, vel = note_starts.pop(pitch)
                duration = t - start_t
                if duration <= 0:
                    continue
                n_samples = int(duration * sample_rate)
                t_arr = np.arange(n_samples) / sample_rate
                wave = (vel / 127.0) * 0.3 * np.sin(2 * np.pi * freq * t_arr)
                envelope = np.exp(-t_arr * 3.0)
                wave = wave * envelope
                start_idx = int(start_t * sample_rate)
                end_idx = start_idx + n_samples
                if end_idx <= len(audio):
                    audio[start_idx:end_idx] += wave

        if np.max(np.abs(audio)) > 0:
            audio = audio / np.max(np.abs(audio)) * 0.8

        wavfile.write(wav_filepath, sample_rate, (audio * 32767).astype(np.int16))
        return True
    except Exception as e:
        print(f"Audio synthesis failed: {e}")
        return False
