"""
MIDI Preprocessing Module
Parses MIDI files into note sequences using music21.
"""

import os
import pickle
import numpy as np
from music21 import converter, instrument, note, chord, stream
from collections import Counter


def parse_midi_file(filepath: str) -> list[str]:
    """Parse a single MIDI file and return a list of note/chord strings."""
    notes = []
    try:
        midi = converter.parse(filepath)
        parts = instrument.partitionByInstrument(midi)
        if parts:
            notes_to_parse = parts.parts[0].recurse()
        else:
            notes_to_parse = midi.flat.notes

        for element in notes_to_parse:
            if isinstance(element, note.Note):
                notes.append(str(element.pitch))
            elif isinstance(element, chord.Chord):
                notes.append(".".join(str(n) for n in element.normalOrder))
    except Exception as e:
        raise ValueError(f"Failed to parse MIDI file '{filepath}': {e}")
    return notes


def parse_midi_files(filepaths: list[str], progress_callback=None) -> list[str]:
    """Parse multiple MIDI files and return combined note sequence."""
    all_notes = []
    for i, fp in enumerate(filepaths):
        try:
            file_notes = parse_midi_file(fp)
            all_notes.extend(file_notes)
        except ValueError as e:
            print(f"Warning: {e}")
        if progress_callback:
            progress_callback(i + 1, len(filepaths))
    return all_notes


def prepare_sequences(notes: list[str], sequence_length: int = 100):
    """
    Prepare input/output sequences for LSTM training.
    Returns:
        network_input: (samples, sequence_length, 1) normalized
        network_output: one-hot encoded
        pitchnames: sorted unique notes
        n_vocab: vocabulary size
        raw_input: (samples, sequence_length) integer-encoded (for generation)
    """
    pitchnames = sorted(set(notes))
    n_vocab = len(pitchnames)
    note_to_int = {note: num for num, note in enumerate(pitchnames)}

    network_input_raw = []
    network_output = []

    for i in range(len(notes) - sequence_length):
        seq_in = notes[i:i + sequence_length]
        seq_out = notes[i + sequence_length]
        network_input_raw.append([note_to_int[c] for c in seq_in])
        network_output.append(note_to_int[seq_out])

    n_patterns = len(network_input_raw)
    network_input = np.reshape(network_input_raw, (n_patterns, sequence_length, 1))
    network_input = network_input / float(n_vocab)
    network_output_encoded = np.zeros((n_patterns, n_vocab))
    for i, val in enumerate(network_output):
        network_output_encoded[i][val] = 1.0

    return network_input, network_output_encoded, pitchnames, n_vocab, network_input_raw


def save_notes(notes: list[str], filepath: str):
    """Save note list to a pickle file."""
    os.makedirs(os.path.dirname(filepath), exist_ok=True) if os.path.dirname(filepath) else None
    with open(filepath, "wb") as f:
        pickle.dump(notes, f)


def load_notes(filepath: str) -> list[str]:
    """Load note list from a pickle file."""
    with open(filepath, "rb") as f:
        return pickle.load(f)


def get_note_statistics(notes: list[str]) -> dict:
    """Return basic statistics about the note sequence."""
    counter = Counter(notes)
    return {
        "total_notes": len(notes),
        "unique_notes": len(counter),
        "most_common": counter.most_common(10),
        "least_common": counter.most_common()[:-11:-1],
    }
