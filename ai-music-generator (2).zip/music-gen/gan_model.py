"""
GAN Music Generation Model
A Generative Adversarial Network for symbolic music generation.

Architecture:
  Generator  — noise vector → Bidirectional LSTM → softmax over vocabulary
  Discriminator — one-hot note sequence → Bidirectional LSTM → real/fake score
"""

import os
import pickle
import numpy as np


def build_generator(latent_dim: int, sequence_length: int, n_vocab: int):
    """
    Generator: maps a random noise vector to a note-probability sequence.
    Output shape: (sequence_length, n_vocab)  (soft one-hot via softmax)
    """
    from tensorflow.keras.models import Model
    from tensorflow.keras.layers import (
        Input, Dense, Reshape, Bidirectional, LSTM,
        TimeDistributed, Dropout, LeakyReLU, BatchNormalization,
    )

    noise = Input(shape=(latent_dim,), name="gen_noise")

    x = Dense(sequence_length * 64)(noise)
    x = LeakyReLU(0.2)(x)
    x = BatchNormalization()(x)
    x = Reshape((sequence_length, 64))(x)

    x = Bidirectional(LSTM(256, return_sequences=True))(x)
    x = Dropout(0.3)(x)
    x = Bidirectional(LSTM(256, return_sequences=True))(x)
    x = Dropout(0.3)(x)

    output = TimeDistributed(Dense(n_vocab, activation="softmax"), name="gen_out")(x)

    return Model(noise, output, name="Generator")


def build_discriminator(sequence_length: int, n_vocab: int):
    """
    Discriminator: classifies a note sequence as real or generated.
    Input shape: (sequence_length, n_vocab)
    Output: probability of being real (scalar)
    """
    from tensorflow.keras.models import Model
    from tensorflow.keras.layers import (
        Input, Bidirectional, LSTM, Dense, Dropout, LeakyReLU, Flatten,
    )

    seq_input = Input(shape=(sequence_length, n_vocab), name="disc_seq")

    x = Bidirectional(LSTM(256, return_sequences=True))(seq_input)
    x = Dropout(0.4)(x)
    x = Bidirectional(LSTM(128, return_sequences=False))(x)
    x = Dropout(0.4)(x)
    x = Dense(128)(x)
    x = LeakyReLU(0.2)(x)
    output = Dense(1, activation="sigmoid", name="disc_out")(x)

    return Model(seq_input, output, name="Discriminator")


def build_gan(generator, discriminator):
    """Build the combined GAN (for training the generator)."""
    from tensorflow.keras.models import Model
    from tensorflow.keras.layers import Input

    discriminator.trainable = False
    noise = Input(shape=(generator.input_shape[-1],), name="gan_noise")
    fake_seq = generator(noise)
    validity = discriminator(fake_seq)
    return Model(noise, validity, name="GAN")


def compile_models(generator, discriminator, gan, lr_d: float = 0.0002, lr_g: float = 0.0002):
    """Compile discriminator and combined GAN."""
    from tensorflow.keras.optimizers import Adam

    discriminator.compile(
        loss="binary_crossentropy",
        optimizer=Adam(lr_d, beta_1=0.5),
        metrics=["accuracy"],
    )
    gan.compile(
        loss="binary_crossentropy",
        optimizer=Adam(lr_g, beta_1=0.5),
    )


def prepare_gan_sequences(notes: list[str], sequence_length: int):
    """
    Produce one-hot encoded real training sequences for the discriminator.
    Returns:
        real_seqs: (n_samples, sequence_length, n_vocab) float32
        pitchnames: sorted unique note list
        n_vocab: int
        note_to_int: mapping dict
    """
    pitchnames = sorted(set(notes))
    n_vocab = len(pitchnames)
    note_to_int = {n: i for i, n in enumerate(pitchnames)}

    real_seqs = []
    for i in range(len(notes) - sequence_length):
        seq = notes[i: i + sequence_length]
        one_hot = np.zeros((sequence_length, n_vocab), dtype=np.float32)
        for t, n in enumerate(seq):
            one_hot[t, note_to_int[n]] = 1.0
        real_seqs.append(one_hot)

    return np.array(real_seqs, dtype=np.float32), pitchnames, n_vocab, note_to_int


def train_gan(
    generator,
    discriminator,
    gan,
    real_seqs: np.ndarray,
    latent_dim: int,
    epochs: int = 100,
    batch_size: int = 64,
    streamlit_callback=None,
    save_dir: str = "saved_models",
) -> list[dict]:
    """
    Adversarial training loop.
    Returns a list of per-epoch loss dicts:
      [{"epoch": int, "d_loss": float, "d_acc": float, "g_loss": float}, ...]
    """
    os.makedirs(save_dir, exist_ok=True)
    history = []
    n_samples = len(real_seqs)
    best_g_loss = float("inf")

    for epoch in range(epochs):
        idx = np.random.randint(0, n_samples, batch_size)
        real_batch = real_seqs[idx]

        noise = np.random.normal(0, 1, (batch_size, latent_dim)).astype(np.float32)
        fake_batch = generator.predict(noise, verbose=0)

        real_labels = np.ones((batch_size, 1)) * 0.9
        fake_labels = np.zeros((batch_size, 1)) + 0.1

        discriminator.trainable = True
        d_loss_real = discriminator.train_on_batch(real_batch, real_labels)
        d_loss_fake = discriminator.train_on_batch(fake_batch, fake_labels)
        d_loss = 0.5 * (d_loss_real[0] + d_loss_fake[0])
        d_acc = 0.5 * (d_loss_real[1] + d_loss_fake[1])
        discriminator.trainable = False

        noise = np.random.normal(0, 1, (batch_size, latent_dim)).astype(np.float32)
        g_loss = gan.train_on_batch(noise, np.ones((batch_size, 1)))

        entry = {
            "epoch": epoch + 1,
            "d_loss": float(d_loss),
            "d_acc": float(d_acc),
            "g_loss": float(g_loss),
        }
        history.append(entry)

        if g_loss < best_g_loss:
            best_g_loss = g_loss
            generator.save(os.path.join(save_dir, "gan_generator_best.keras"))

        if streamlit_callback:
            streamlit_callback(epoch, entry)

    generator.save(os.path.join(save_dir, "gan_generator_final.keras"))
    discriminator.save(os.path.join(save_dir, "gan_discriminator_final.keras"))
    return history


def gan_generate_notes(
    generator,
    pitchnames: list[str],
    n_vocab: int,
    num_notes: int = 200,
    latent_dim: int = 100,
    temperature: float = 1.0,
) -> list[str]:
    """
    Generate a sequence of note names from the trained generator.
    The generator produces (sequence_length, n_vocab) chunks; these are
    concatenated until num_notes is reached.
    """
    sequence_length = generator.output_shape[1]
    generated = []
    int_to_note = {i: n for i, n in enumerate(pitchnames)}

    chunks_needed = max(1, -(-num_notes // sequence_length))
    for _ in range(chunks_needed):
        noise = np.random.normal(0, 1, (1, latent_dim)).astype(np.float32)
        probs = generator.predict(noise, verbose=0)[0]

        for t in range(sequence_length):
            p = probs[t].astype(np.float64)
            if temperature != 1.0:
                p = np.log(p + 1e-10) / temperature
                p = np.exp(p)
            p = p / p.sum()
            idx = np.random.choice(n_vocab, p=p)
            generated.append(int_to_note[idx])

    return generated[:num_notes]


def load_gan_generator(path: str):
    """Load a saved GAN generator from disk."""
    from tensorflow.keras.models import load_model
    return load_model(path)


def save_gan_history(history: list[dict], path: str):
    """Persist GAN training history as a pickle."""
    os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
    with open(path, "wb") as f:
        pickle.dump(history, f)


def load_gan_history(path: str) -> list[dict]:
    """Load persisted GAN training history."""
    with open(path, "rb") as f:
        return pickle.load(f)
