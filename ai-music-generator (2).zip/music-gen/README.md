# AI Music Generator

An AI-powered MIDI music generation app built with Streamlit and TensorFlow/Keras. 
Upload MIDI files, train an LSTM model on note sequences, and generate brand-new compositions.

---

## Features

- Upload multiple MIDI files as a training dataset
- Preprocess MIDI into note/chord token sequences using `music21`
- Train a stacked LSTM neural network to learn musical patterns
- Generate new music with adjustable creativity (temperature)
- Download the result as a `.mid` MIDI file
- Audio preview via in-browser sine-wave synthesis

---

## Quick Start

### 1. Clone / download the project

```bash
git clone <your-repo-url>
cd music-gen
```

### 2. Create and activate a virtual environment (recommended)

```bash
python -m venv venv
source venv/bin/activate      # macOS / Linux
venv\Scripts\activate         # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

> **Note:** `tensorflow-cpu` is used by default. For GPU training, replace it with `tensorflow` in `requirements.txt`.

### 4. Run the app

```bash
streamlit run app.py
```

The app opens at `http://localhost:8501`.

---

## Usage

| Step | Tab | Action |
|------|-----|--------|
| 1 | Upload Dataset | Upload one or more `.mid` / `.midi` files and click **Process MIDI Files** |
| 2 | Train Model | Adjust epochs / batch size in the sidebar, then click **Start Training** |
| 3 | Generate Music | Click **Generate Music** — adjust note count and temperature in the sidebar |
| 4 | Download | Click **Download MIDI File** to save your composition |

---

## Folder Structure

```
music-gen/
├── app.py                  # Main Streamlit application
├── preprocess.py           # MIDI parsing and sequence preparation (music21)
├── model.py                # LSTM model architecture and training
├── generate.py             # Note generation and MIDI export
├── utils.py                # Shared helpers and path constants
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── .streamlit/
│   └── config.toml         # Streamlit server and theme config
├── saved_models/           # Auto-created: trained model + note cache
│   ├── music_model.keras
│   ├── checkpoint.keras
│   ├── notes.pkl
│   └── pitchnames.pkl
├── output/                 # Auto-created: generated MIDI and WAV
│   ├── generated_music.mid
│   └── generated_music.wav
└── sample_midi/            # Put sample .mid files here for quick testing
```

---

## Configuration (sidebar)

| Parameter | Default | Description |
|-----------|---------|-------------|
| Sequence length | 100 | How many notes the model looks back at |
| Training epochs | 50 | More = better quality, slower training |
| Batch size | 64 | Training mini-batch size |
| Notes to generate | 200 | Length of the output composition |
| Temperature | 1.0 | Creativity: lower = structured, higher = experimental |

---

## Model Architecture

```
Input shape: (sequence_length, 1)

LSTM(512, return_sequences=True)
Dropout(0.3)
LSTM(512)
Dropout(0.3)
Dense(256) + BatchNorm + ReLU
Dropout(0.3)
Dense(n_vocab, softmax)

Optimizer: RMSprop(lr=0.001)
Loss: categorical_crossentropy
```

---

## Where to Get MIDI Files

- [MIDI World](http://www.midiworld.com) — free classical and pop MIDI
- [Classical Archives](https://www.classicalarchives.com) — classical repertoire
- [Josquin Research Project](https://josquin.stanford.edu) — Renaissance polyphony
- [MagnaTagATune](http://mirg.city.ac.uk/codeapps/the-magnatagatune-dataset) — large ML-ready dataset

---

## Requirements

- Python ≥ 3.9
- See `requirements.txt` for full list

---

## License

MIT
